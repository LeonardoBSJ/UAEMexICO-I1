package fibonachi;

import javax.swing.JOptionPane;

public class Fibonachi {

    public static int fibo(int n) {

        if (n == 0) {

            return 0;
        } else if (n == 1) {

            return 1;
        } else {

            return fibo(n - 1) + fibo(n - 2);
        }

    }

    public static void main(String[] args) {

        int n = Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de su fibonachi"));
        System.out.println("");

        for (int i = 0; i < n; i++) {
            System.out.print("");

            System.out.print(fibo(i) + ",");

        }

    }
}


package recursividad;

import javax.swing.JOptionPane;
import java.util.Scanner;
public class Recursividad {
     public static int potencia(int n, int expo) {
        if (expo== 0) {
            return 1;
        } else {
            return n*potencia(n, expo - 1);
        }
    }
   
   public static void main(String[] args) {
       Scanner leer = new Scanner (System.in);
       
      
   
        int numero =Integer.parseInt(JOptionPane.showInputDialog("ingrese su numero a elevar"));

        int exponente =Integer.parseInt(JOptionPane.showInputDialog("ingrese la exponente"));
        System.out.println("");
        
        System.out.println("la operaccion es:" + potencia(numero, exponente));
   }
}

package Prestamo_Fachada;

import PRESTAMO.Libro;
import Prestamos_Daos.LibroDao;
import Servers.BibliServer;
import java.util.ArrayList;
import java.util.List;

public abstract class Libro_Fachada implements BibliServer {

    LibroDao libroDao = new LibroDao();

    public void agregar(List<Libro> lista, Libro libro) {
        libroDao.AgregarLibro(libro);
    }

    public void eliminar(List<Libro> lista, Libro libro) {
        libroDao.EliminarLibro(libro);

    }

    public void buscar(List<Libro> lista, Libro libro) {
        libroDao.BuscarLibro(libro.getId());

    }

    public void actualizar(List<Libro> lista, Libro libro) {
        libroDao.ActualizarLibro(libro);

    }

    public ArrayList<Libro> imprimir(Libro libro) {
        libroDao.ImprimirLibro(libro);
        return null;
    }

}

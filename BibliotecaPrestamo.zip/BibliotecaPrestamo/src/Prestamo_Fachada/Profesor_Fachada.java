
package Prestamo_Fachada;

import PRESTAMO.Profesor;
import Prestamos_Daos.ProfesorDao;
import Servers.BibliServer;
import java.util.ArrayList;
import java.util.List;

public abstract class Profesor_Fachada implements BibliServer {
     ProfesorDao profesorDao = new ProfesorDao();
    
    public void agregar(List<Profesor>lista,Profesor profesor) {
        profesorDao.agregarProfesor(profesor);
    }
    public void eliminar(List<Profesor>lista,Profesor profesor){
        profesorDao.eliminarProfesor(profesor);
        
    }

    public void buscar(List<Profesor>lista,Profesor profesor){    
        profesorDao.buscarProfesor(profesor.getId());
        
    }
    
       public void actualizar (List<Profesor>lista,Profesor profesor){
        profesorDao.actualizarProfesor(profesor);
    }
       
       public ArrayList<Profesor> imprimir (Profesor profesor){
           profesorDao.imprimirProfesor(profesor);
         return null;
       }
}

package Prestamo_Fachada;

import Prestamos_Daos.AlumnoDao;
import PRESTAMO.Alumno;
import Servers.BibliServer;
import java.util.ArrayList;
import java.util.List;

public abstract class AlumnoBDFachada implements BibliServer{
    AlumnoDao alumnoDao = new AlumnoDao();
    
    public void agregar(List<Alumno>lista, Alumno alumno) {
        alumnoDao.agregarAlumno(alumno);
    }
    public void eliminar(List<Alumno>lista,Alumno alumno){
        alumnoDao.eliminarAlumno(alumno);
        
    }

    public void buscar(List<Alumno>lista,Alumno alumno){    
        alumnoDao.buscarAlumno(alumno.getId());
        
    }
    
       public void actualizar (List<Alumno>lista,Alumno alumno){
        alumnoDao.actualizarAlumno(alumno);
    }
        public ArrayList<Alumno> imprimir (Alumno alumno){
       alumnoDao.imprimirAlumno(alumno);
        return null; 
    }

}

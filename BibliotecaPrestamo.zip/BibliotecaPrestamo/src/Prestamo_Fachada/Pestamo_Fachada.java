package Prestamo_Fachada;

import PRESTAMO.Prestamo;
import Prestamos_Daos.PrestamoDao;
import java.util.List;
import Servers.BibliServer;

public abstract class Pestamo_Fachada implements BibliServer {

    PrestamoDao prestamoDao = new PrestamoDao();

    public void agregar(List<Prestamo>lista,Prestamo prestamo) {
        prestamoDao.AgregarPrestamo(prestamo);
    }

    public void eliminar(List<Prestamo>lista,Prestamo prestamo) {
        prestamoDao.EliminarPrestamo(prestamo);

    }

    public List<Prestamo> buscar(Prestamo prestamo) {
        prestamoDao.BuscarPrestamo(prestamo.getId());
        return null;

    }

    public List<Prestamo> actualizar(Prestamo prestamo) {
        prestamoDao.ActualizarPrestamo(prestamo);
        return null;
    }

    public List<Prestamo> imprimir(Prestamo prestamo) {
        return prestamoDao.imprimirListaPrestamos();

    }

}

package Prestamo_Fachada;

import Test.Tres_Prestamos;

public class Tres_prestamoFachada {

    public static void main(String[] args) {
        Tres_Prestamos tres_prestamos = new Tres_Prestamos();
        tres_prestamos.testrun();
    }
}

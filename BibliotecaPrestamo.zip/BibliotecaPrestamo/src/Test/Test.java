
package Test;

import java.util.List;
import Prestamos_Daos.AlumnoDao;
import Prestamos_Daos.LibroDao;
import Prestamos_Daos.PrestamoDao;
import Prestamos_Daos.ProfesorDao;
import PRESTAMO.Alumno;
import PRESTAMO.Prestamo;
import PRESTAMO.Profesor;
import PRESTAMO.Libro;
import java.util.Scanner;


public class Test {
    
    AlumnoDao alumnoDao = new AlumnoDao();
    LibroDao libroDao = new LibroDao();
    PrestamoDao prestamoDao = new PrestamoDao();
    ProfesorDao profesorDao = new ProfesorDao();

    public void testCrearPrestamo(Prestamo prestamo) {
        prestamoDao.AgregarPrestamo(prestamo);
        System.out.println("Fin agregar prestamo");

    }

    public void testCrearLibro(Libro libro) {
        libroDao.AgregarLibro(libro);
        System.out.println("Fin agregar");

    }
    
    
    public void testCrearAlumno(Alumno alumno){
        alumnoDao.agregarAlumno(alumno);
        System.out.println("agregoalumno");
    }
    public void testCrearProfesor(Profesor profesor){
        profesorDao.agregarProfesor(profesor);
        System.out.println("AggregarProfesor");
    }
    public void consultarPrestamo() {
        
Scanner leer = new Scanner (System.in);

        //si es diferente de nulo que se imprima
        System.out.println("Desea realizar una busqueda");
        if(leer.nextBoolean()==true){
            
            int statico=1;
            if (statico==1){
                System.out.println("ingrese el id a buscar");
            
        Prestamo p = prestamoDao.BuscarPrestamo(leer.nextInt());
        System.out.println("Bsqueda por id  " + p.toString());
                System.out.println("escriba su otra busqueda");
                System.out.println("");
            }else if (leer.nextInt()>=4){
                
            
                        System.out.println("el numero id no esta en la base de datos");
            }
            
        }else if(false==false){
            System.out.println(" no realizo ninguna operacion");
        }

    }

    public void consultarTodos() {
        List<Prestamo> prestamos = prestamoDao.imprimirListaPrestamos();
        // forech  NombreClase nombreVariaTemporal : nombre de la lista que se recorre
        for (Prestamo p : prestamos) {
            System.out.println(p.toString());
        }

    }
}

package Test;

import PRESTAMO.Alumno;
import PRESTAMO.Libro;
import PRESTAMO.Prestamo;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import PRESTAMO.Profesor;

public class Tres_Prestamos {
public void testrun (){

        Libro libro1 = new Libro();
        libro1.setNombre("Epitemologia en la antropologia");
        libro1.setCategoria("epitemologia");
        libro1.setEditorial("algeoranial");
        libro1.setIsbn(1232157534);
        libro1.setStock(3);

        Libro libro2 = new Libro();
        libro2.setNombre("Fundamentos de programacion");
        libro2.setCategoria("programacion");
        libro2.setEditorial("españa");
        libro2.setIsbn(993);
        libro2.setStock(7);

        List<Libro> listaLibros1 = new ArrayList<>();
        listaLibros1.add(libro2);
        listaLibros1.add(libro1);

        Alumno alumno1 = new Alumno();
        alumno1.setId(1);
        alumno1.setNombre("Juan ");
        alumno1.setApellidoPaterno("Hernandez ");
        alumno1.setApellidoMaterno("Rios");
        alumno1.setNumeroCuenta(2022435);

        Prestamo prestamo1 = new Prestamo();
        Date fechaIni = new Date();
        prestamo1.setId(1);
        prestamo1.setFolio(12345);
        prestamo1.setFechainicio(fechaIni);
        prestamo1.setFechaentrega(fechaIni);
        prestamo1.setEstatus("profesor");
        prestamo1.setPersona(alumno1);
        prestamo1.setLibros(listaLibros1);

        //fin de primer prestamo
        Libro libro3 = new Libro();
        libro3.setNombre("Principios de calculo");
        libro3.setCategoria("calculo 2");
        libro3.setEditorial("editororial españa");
        libro3.setIsbn(123456789);
        libro3.setStock(8);

        Libro libro4 = new Libro();
        libro4.setNombre("java");
        libro4.setCategoria("programacion");
        libro4.setEditorial("editorial españa");
        libro4.setIsbn(888);
        libro4.setStock(2);

        List<Libro> listaLibros2 = new ArrayList<>();
        listaLibros2.add(libro3);
        listaLibros2.add(libro4);
        
        Alumno alumno2 = new Alumno();
        alumno2.setId(2);
        alumno2.setNombre("Alan ");
        alumno2.setApellidoPaterno("Martinez ");
        alumno2.setApellidoMaterno("Rios");
        alumno2.setNumeroCuenta(2022435);

        Prestamo prestamo2 = new Prestamo();
        Date fechaIni2 = new Date();
        prestamo2.setId(2);
        prestamo2.setFolio(111213);
        prestamo2.setFechainicio(fechaIni2);
        prestamo2.setFechaentrega(fechaIni2);
        prestamo2.setEstatus("Estudinte");
        prestamo2.setPersona(alumno2);
        prestamo2.setLibros(listaLibros2);

        //fin del segundo prestamo
        Libro libro5 = new Libro();
        libro5.setNombre("Geometria");
        libro5.setCategoria("Geometria Analitica");
        libro5.setEditorial("editororial españa");
        libro5.setIsbn(987654321);
        libro5.setStock(4);

        List<Libro> listaLibros3 = new ArrayList<>();
        listaLibros3.add(libro5);

        Alumno alumno3 = new Alumno();
        alumno3.setId(3);
        alumno3.setNombre("Juan ");
        alumno3.setApellidoPaterno("Hernandez ");
        alumno3.setApellidoMaterno("Rios");
        alumno3.setNumeroCuenta(1917678);

        Prestamo prestamo3 = new Prestamo();
        Date fechaIni3 = new Date();
        prestamo3.setId(3);
        prestamo3.setFolio(67890);
        prestamo3.setFechainicio(fechaIni2);
        prestamo3.setFechaentrega(fechaIni3);
        prestamo3.setEstatus("Estudiante");
        prestamo3.setPersona(alumno3);
        prestamo3.setLibros(listaLibros3);
        //fin prestamo 3
        Libro libro6 = new Libro();
        libro6.setId(4);
        libro6.setNombre("Fundamentos de programacion");
        libro6.setCategoria("Programación");
        libro6.setEditorial("Alfaomega");
        libro6.setIsbn(2324);
        libro6.setStock(5);

        Libro libro7 = new Libro();
        libro7.setId(1);
        libro7.setNombre("Calculo");
        libro7.setCategoria("Matematicas");
        libro7.setEditorial("Alfaomega");
        libro7.setIsbn(344);
        libro7.setStock(2);

        List<Libro> listaLibros4 = new ArrayList<>();
        listaLibros4.add(libro7);
        listaLibros4.add(libro6);

        Profesor profesor1 = new Profesor();
        profesor1.setId(1);
        profesor1.setNombre("Diego");
        profesor1.setApellidoPaterno("Hernadez");
        profesor1.setApellidoMaterno("Ruiz");
        profesor1.setNumeroEmpleado(20227102);
        
        Prestamo prestamo4 = new Prestamo();
        Date fechaIni4 = new Date();
        prestamo4.setId(4);
        prestamo4.setFolio(84638);
        prestamo4.setFechainicio(fechaIni4);
        prestamo4.setFechaentrega(fechaIni);
        prestamo4.setEstatus("Profesor");
        prestamo4.setPersona(profesor1);
        prestamo4.setLibros(listaLibros4);
         
        
        Test test1 = new Test();
        test1.testCrearLibro(libro1);
        test1.testCrearLibro(libro2);
        test1.testCrearLibro(libro3);
        test1.testCrearLibro(libro4);
        test1.testCrearLibro(libro5);
        test1.testCrearLibro(libro6);
        test1.testCrearLibro(libro7);
        test1.testCrearAlumno(alumno1);
        test1.testCrearAlumno(alumno2);
        test1.testCrearAlumno(alumno3);
        test1.testCrearProfesor(profesor1);
        test1.testCrearPrestamo(prestamo1);
        test1.testCrearPrestamo(prestamo2);
        test1.testCrearPrestamo(prestamo3);
        test1.testCrearPrestamo(prestamo4);
       
        test1.consultarTodos();
        test1.consultarPrestamo();
        
        

    
}
}

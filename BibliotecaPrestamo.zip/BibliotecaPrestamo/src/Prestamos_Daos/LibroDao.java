
package Prestamos_Daos;

import java.util.ArrayList;
import java.util.List;
import PRESTAMO.Libro;
public class LibroDao {
   public  List<Libro> libros = new ArrayList<>();
   public ArrayList<Libro> lista = new ArrayList<>();  
    public void AgregarLibro(Libro libro) {
        libros.add(libro);

    }

    public void EliminarLibro(Libro libro) {
        libros.remove(libro);
    }

    public Libro BuscarLibro(int id) {
        for (int i = 0; i < libros.size(); i++) {
            Libro a= libros.get(i);
            if(a.getId()== id ){
                System.out.println(a.getId());
                 return a;
            }
        }
         return null;
     
    }
    
    
        public void  ActualizarLibro(Libro libro) {
        for (int i = 0; i < libros.size(); i++) {
          if(libros.get(i).getId()== libro.getId()){
              libros.get(i).setNombre(libro.getNombre());
          }
            }
        }
     
    
    public void ImprimirLibro(Libro libro){
       for (int i = 0; i < lista.size(); i++) {
           System.out.println(lista.get(i).toString());
       
        } 
         
       

    }  
}

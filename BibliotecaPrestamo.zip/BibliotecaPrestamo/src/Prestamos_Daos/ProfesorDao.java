
package Prestamos_Daos;

import PRESTAMO.Profesor;
import java.util.ArrayList;
import java.util.List;

public class ProfesorDao {
    
    public List<Profesor> profesores = new ArrayList<>();
    public ArrayList<Profesor> lista  = new ArrayList<Profesor>();
    public void agregarProfesor(Profesor profesor) {
        profesores.add(profesor);

    }

    public void eliminarProfesor(Profesor profesor) {
        profesores.remove(profesor);
    }

    public Profesor buscarProfesor(int id) {
        for (int i = 0; i < profesores.size(); i++) {
            Profesor a = profesores.get(i);
            if (a.getId() == id) {
               System.out.println(a.getId());
                return a;
            }
        }
        return null;

    }

    public void actualizarProfesor(Profesor profesor) {
        for (int i = 0; i < profesores.size(); i++) {
            if (profesores.get(i).getId() == profesor.getId()) {
                profesores.get(i).setNombre(profesor.getNombre());
                profesores.get(i).setApellidoMaterno(profesor.getApellidoMaterno());
            }
        }
    }

    public void imprimirProfesor(Profesor profesor) {
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i).toString());

        }
    }
}


package Prestamos_Daos;

import java.util.ArrayList;
import java.util.List;
import PRESTAMO.Prestamo;

public class PrestamoDao {
    //crud
    public List<Prestamo> prestamos = new ArrayList<>();

    public void AgregarPrestamo(Prestamo prestamo) {
        prestamos.add(prestamo);

    }

    public void EliminarPrestamo(Prestamo prestamo) {
        prestamos.remove(prestamo);
    }

    public Prestamo BuscarPrestamo(int id) {
        for (int i = 0; i < prestamos.size(); i++) {
            Prestamo a = prestamos.get(i);
            if (a.getId() == id) {
                 System.out.println(a.getId());
                return a;
            }
        }
        return null;

    }

    public void ActualizarPrestamo(Prestamo prestamo) {
        for (int i = 0; i < prestamos.size(); i++) {
            if (prestamos.get(i).getId() == prestamo.getId()) {
                prestamos.get(i).setFolio(prestamo.getFolio());
            }
        }
    }

    public List<Prestamo> imprimirListaPrestamos() {
        return prestamos;
      
    }
}


package serviciomusica;

import java.util.List;
import musica.Album;
import java.util.ArrayList;
import musica.Artista;
import musica.Cancion;
public interface servicioMusica {
    
    public List<Album> agregarAlbum(Album album);
    public List<Album> eliminarAlbum(Album album);
    public List<Album> buscarAlbum(Album album);
    public List<Album> actualizarAlbum(Album album);
    public ArrayList<Album> imprimirAlbum(Album album);
    
    public List<Artista> agregarArtista(Artista artista);
    public List<Artista> eliminarArtista(Artista artista);
    public List<Artista> buscarArtista(Artista artista);
    public List<Artista> actualizarArtista(Artista artista);
    public List<Artista> imprimirArtista(Artista artista);
    
    public List<Cancion> agregarCancion(Cancion cancion);
    public List<Cancion> eliminarCancion(Cancion cancion);
    public List<Cancion> buscarCancion(Cancion cancion);
    public List<Cancion> actualizarCancion(Cancion cancion);
    public ArrayList<Cancion> imprimirCancion(Cancion cancion);
    
}

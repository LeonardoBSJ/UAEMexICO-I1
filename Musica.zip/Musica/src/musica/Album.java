
package musica;

import java.util.List;

public class Album {
    private int id;
    protected List<Cancion> canciones;
    protected String Nombre;
    protected int fechaLazamiento;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Cancion> getCanciones() {
        return canciones;
    }

    public void setCanciones(List<Cancion> canciones) {
        this.canciones = canciones;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getFechaLazamiento() {
        return fechaLazamiento;
    }

    public void setFechaLazamiento(int fechaLazamiento) {
        this.fechaLazamiento = fechaLazamiento;
    }

    @Override
    public String toString() {
        return "Album{" + "id=" + id + ", canciones=" + canciones + ", Nombre=" + Nombre + ", fechaLazamiento=" + fechaLazamiento + '}';
    }

    
}


package musica.Dao;
import musica.Album;
import java.util.ArrayList;
import java.util.List;

public class AlbumDao {
    public List<Album> albums = new ArrayList<>();
    public ArrayList<Album> lista = new ArrayList<>();  

public void agregarAlbum(Album album){
    albums.add(album);
}
public void eliminarAlbum(Album album){
    albums.remove(album);
}
public Album buscarAlbum(int id) {
        for (int i = 0; i < albums.size(); i++) {
            Album a = albums.get(i);
            if (a.getId() == id) {
                 System.out.println(a.getId());
                return a;
            }
        }
        return null;
}
 public void actualizarAlbum(Album album) {
        for (int i = 0; i < albums.size(); i++) {
            if (albums.get(i).getId() == album.getId()) {
                albums.get(i).setNombre(album.getNombre());
                albums.get(i).setFechaLazamiento(album.getFechaLazamiento());
            }
        }
    }

    public List<Album> imprimirAlbum() {
        return albums;
    }
    
}

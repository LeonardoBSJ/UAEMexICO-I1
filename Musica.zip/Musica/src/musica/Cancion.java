
package musica;
public class Cancion {
    private int id;
    protected String nombre;
    public String fechaCancion;
    public String Compositor;
    public String genero;
    


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFechaCancion() {
        return fechaCancion;
    }

    public void setFechaCancion(String fechaCancion) {
        this.fechaCancion = fechaCancion;
    }

    public String getCompositor() {
        return Compositor;
    }

    public void setCompositor(String Compositor) {
        this.Compositor = Compositor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Cancion{" + "id=" + id + ", nombre=" + nombre + ", fechaCancion=" + fechaCancion + ", Compositor=" + Compositor + ", genero=" + genero + '}';
    }
  
}

package musica.Facade;

import Test.Main;

public class MainFacade {

    public static void main(String[] args) {

        Main main = new Main();
        main.FacadeTest();

    }

}

package musica.Facade;

import java.util.List;
import java.util.ArrayList;
import musica.Cancion;

public class cancionDao {

    cancionDao canciondao = new cancionDao();

    public List<Cancion> agregarcan(Cancion cancion) {
        canciondao.agregarcan(cancion);
        return null;
    }

    public List<Cancion> eliminarcan(Cancion cancion) {
        canciondao.eliminarcan(cancion);
        return null;
    }

    public List<Cancion> buscarcan(Cancion cancion) {
        canciondao.buscarcan(cancion);
        return null;
    }

    public List<Cancion> actualizarcan(Cancion cancion) {
        canciondao.actualizarcan(cancion);
        return null;
    }

    public ArrayList<Cancion> imprimircan(Cancion cancion) {
        canciondao.imprimircan(cancion);
        return null;
    }
}

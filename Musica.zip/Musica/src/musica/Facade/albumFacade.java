package musica.Facade;

import java.util.ArrayList;
import java.util.List;
import musica.Album;
import musica.Dao.AlbumDao;
import serviciomusica.servicioMusica;

public abstract class albumFacade implements servicioMusica {

    AlbumDao albumDao = new AlbumDao();

    public void agregarAlb(List<Album> lista, Album album) {
        albumDao.agregarAlbum(album);
    }

    public void eliminarAlb(List<Album> lista, Album album) {
        albumDao.eliminarAlbum(album);
    }

    public void buscarAlb(List<Album> lista, Album album) {
        albumDao.buscarAlbum(album.getId());
    }

    public void actualizarAlb(List<Album> lista, Album album) {
        albumDao.actualizarAlbum(album);
    }

    public void imprimirAlb(ArrayList<Album> lista, Album album) {
        albumDao.imprimirAlbum();
    }
}

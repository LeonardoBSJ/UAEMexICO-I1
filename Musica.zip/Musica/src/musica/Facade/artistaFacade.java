
package musica.Facade;
import java.util.List;
import musica.Artista;
import musica.Dao.artistaDao;

public class artistaFacade {
    artistaDao artistadao=new artistaDao();
    public List<Artista> agregarart(Artista artista){
        artistadao.agregarArtista(artista);
        return null;
    }
    public List<Artista> eliminarart(Artista artista){
        artistadao.eliminarArtista(artista);
        return null;
    }
    public List<Artista> buscarart(Artista artista){
        artistadao.buscarArtista(artista.getId());
        return null;
    }
    public List<Artista> actualizarart(Artista artista){
        artistadao.actualizarArtista(artista);
        return null;
    }
    public void imprimirart(List<Artista>lista,Artista artista){
        artistadao.imprimirArtista();
    }
}

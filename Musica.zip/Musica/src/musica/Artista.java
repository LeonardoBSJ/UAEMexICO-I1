
package musica;


public class Artista extends Persona {
   private int id;
   private String nombreArtistico;
   private String Grupo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreArtistico() {
        return nombreArtistico;
    }

    public void setNombreArtistico(String nombreArtistico) {
        this.nombreArtistico = nombreArtistico;
    }

    public String getGrupo() {
        return Grupo;
    }

    public void setGrupo(String Grupo) {
        this.Grupo = Grupo;
    }

    @Override
    public String toString() {
        return "Artista{" + "id=" + id + ", nombreArtistico=" + nombreArtistico + ", Grupo=" + Grupo + '}';
    }
   
}

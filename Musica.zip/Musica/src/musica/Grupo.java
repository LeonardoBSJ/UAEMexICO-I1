
package musica;

import java.util.List;


public class Grupo {
    private int id;
    protected String nombreGrupo;
    private List<Artista> artistas;

    
    public int getId() {
        return id;
    }

    
    public void setId(int id) {
        this.id = id;
    }

    public String getNombreGrupo() {
        return nombreGrupo;
    }

    public void setNombreGrupo(String nombreGrupo) {
        this.nombreGrupo = nombreGrupo;
    }

    public List<Artista> getArtistas() {
        return artistas;
    }

    public void setArtistas(List<Artista> artistas) {
        this.artistas = artistas;
    }

    @Override
    public String toString() {
        return "Grupo{" + "id=" + id + ", nombreGrupo=" + nombreGrupo + ", artistas=" + artistas + '}';
    }

    
    
}

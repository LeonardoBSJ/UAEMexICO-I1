package Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import musica.Album;
import musica.Artista;
import musica.Cancion;
import Test.Test1;

public class Main {
    public void FacadeTest(){
    
        Cancion cancion1 = new Cancion();
        cancion1.setId(1);
        cancion1.setCompositor("Ed sheeran, Ricky Reed");
        cancion1.setGenero("pop");
        cancion1.setNombre("Bamm Bamm");
        cancion1.setFechaCancion("2019");

        Cancion cancion2 = new Cancion();
        cancion2.setId(2);
        cancion2.setCompositor("camila cabello");
        cancion2.setGenero("pop");
        cancion2.setNombre("Havana");
        cancion2.setFechaCancion("2018");

        Cancion cancion3 = new Cancion();
        cancion3.setId(3);
        cancion3.setCompositor("camila cabello");
        cancion3.setGenero("pop");
        cancion3.setNombre("Never Be the Same ");
        cancion3.setFechaCancion("2018");
        List<Cancion> listacancion1 = new ArrayList<>();
        listacancion1.add(cancion1);
        listacancion1.add(cancion2);
        listacancion1.add(cancion3);

        Artista Artistas1 = new Artista();
        Artistas1.setId(1);
        Artistas1.setGrupo("camila");
        Artistas1.setNombreArtistico("Camila cabello");

        Album album1 = new Album();
        album1.setId(1);
        album1.setFechaLazamiento(2018);
        album1.setCanciones(listacancion1);
        album1.setNombre("camila");
        album1.setCanciones(listacancion1);
       
        //fin del primer album
        
        Cancion cancion4 = new Cancion();
        cancion4.setId(4);
        cancion4.setCompositor("Alexandra Tamposi, Andrew Wotman, Jonathan Bellion");
        cancion4.setGenero("pop");
        cancion4.setNombre("Shameless");
        cancion4.setFechaCancion("5 de septiembre de 2019");
        

        Cancion cancion5 = new Cancion();
        cancion5.setId(5);
        cancion5.setCompositor("cabello, Tamposi, Justin Trainter");
        cancion5.setGenero("pop");
        cancion5.setNombre("Living Proof");
        cancion5.setFechaCancion("15 de noviembre de 2019");

        Cancion cancion6 = new Cancion();
        cancion6.setId(6);
        cancion6.setCompositor("cabello, Shawn Mendes, Charlotte Aitchison");
        cancion6.setGenero("pop");
        cancion6.setNombre("señorita ");
        cancion6.setFechaCancion("2019");
        List<Cancion> listacancion2 = new ArrayList<>();
        listacancion2.add(cancion4);
        listacancion2.add(cancion5);
        listacancion2.add(cancion6);

        Artista Artistas2 = new Artista();
        Artistas2.setId(2);
        Artistas2.setGrupo("camila");
        Artistas2.setNombreArtistico("Camila cabello");
        Artistas2.setGrupo("camilla befo");
        

        Album album2 = new Album();
        album2.setId(2);
        album2.setFechaLazamiento(06+12+2019);
        album2.setCanciones(listacancion2);
        album2.setNombre("Romance");
        album2.setCanciones(listacancion2);
        
        
        Test1 Testmenu = new Test1();
        Testmenu.Almacenarcanciones(cancion1);
        Testmenu.Almacenarcanciones(cancion2);
        Testmenu.Almacenarcanciones(cancion3);
        Testmenu.Almacenarcanciones(cancion4);
        Testmenu.Almacenarcanciones(cancion5);
        Testmenu.Almacenarcanciones(cancion6);
        Testmenu.Alamacenarartista(Artistas1);
        Testmenu.Alamacenarartista(Artistas2);
        Testmenu.Almacenaralbum(album1);
        Testmenu.Almacenaralbum(album2);
        
        Testmenu.consultartodoalbum();
        Testmenu.consultartodoartistas();
        Testmenu.consultartodocanciones();
        Testmenu.consultaralbum();
        Testmenu.consultarartista();
        Testmenu.consultarCancion();
    }
}

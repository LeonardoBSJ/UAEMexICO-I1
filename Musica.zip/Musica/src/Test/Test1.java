package Test;

import musica.Album;
import musica.Artista;
import musica.Cancion;
import musica.Dao.AlbumDao;
import musica.Dao.CancionDao;
import musica.Dao.artistaDao;
import java.util.List;

public class Test1 {

    AlbumDao albumDao = new AlbumDao();
    CancionDao cancionDao = new CancionDao();
    artistaDao artistaDao = new artistaDao();

    public void Almacenarcanciones(Cancion cancion) {
        cancionDao.agregarCancion(cancion);
        System.out.println("Fin Agregar canciones");
        System.out.println("");
    }

    public void Alamacenarartista(Artista artista) {
        artistaDao.agregarArtista(artista);
        System.out.println("Fin Agregar artista");
        System.out.println("");
    }

    public void Almacenaralbum(Album album) {
        albumDao.agregarAlbum(album);
        System.out.println("Fin Agregar album");
        System.out.println("");
    }
    
    public void consultaralbum() {
        Album a = albumDao.buscarAlbum(1);
        System.out.println("La busqueda por id es:"+a.toString());
        System.out.println("");
    }

    public void consultartodoalbum() {
        List<Album> Albums = albumDao.imprimirAlbum();
        for (Album a : Albums) {
            System.out.println(a.toString());
        }
        System.out.println("");
    }
    public void consultarCancion(){
        Cancion b=cancionDao.buscarCancion(5);
        System.out.println("La busqueda por id es:"+b.toString());
        System.out.println("");
    }
    public void consultartodocanciones(){
        List<Cancion> canciones=cancionDao.imprimirCancion();
        for(Cancion b: canciones){
            System.out.println(b.toString());
        }
    }
    public void consultarartista(){
        Artista c=artistaDao.buscarArtista(2);
        System.out.println("La busqueda por id de artista es:"+c.toString());
    }
    public void consultartodoartistas(){
        List<Artista> artistas= artistaDao.imprimirArtista();
        for(Artista c: artistas){
            System.out.println(c.toString());
        }
    }
}
